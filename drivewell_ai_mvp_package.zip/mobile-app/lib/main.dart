
import 'package:flutter/material.dart';

void main() {
  runApp(DriveWellApp());
}

class DriveWellApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DriveWell AI',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('DriveWell AI')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: () {}, child: Text('Start Drive')),
            SizedBox(height: 12),
            ElevatedButton(onPressed: () {}, child: Text('View Dashboard')),
          ],
        ),
      ),
    );
  }
}
