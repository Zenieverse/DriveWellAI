# Backend (FastAPI) - DriveWell AI

## Quickstart (local)
1. Create virtualenv: `python -m venv venv && source venv/bin/activate`
2. Install requirements: `pip install -r requirements.txt`
3. Run: `uvicorn api.main:app --reload --host 0.0.0.0 --port 8000`

This is an MVP skeleton. Add DB, auth and telemetry persistence as needed.
