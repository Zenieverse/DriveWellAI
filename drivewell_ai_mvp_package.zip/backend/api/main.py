from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import time, hashlib

app = FastAPI(title="DriveWell AI - Backend API", version="0.1")

class Telemetry(BaseModel):
    device_id: str
    timestamp: str
    wellness_score: int
    fatigue_probability: float
    stress_probability: float
    location: Optional[dict] = None
    metadata: Optional[dict] = None

@app.get("/")
def root():
    return {"message": "DriveWell AI backend running"}

@app.post("/api/v1/telemetry")
def receive_telemetry(payload: Telemetry):
    # In MVP this simply validates and returns an acknowledgement.
    # In production, add auth, DB writes, and stream processing.
    # Device ID must be hashed to avoid raw identifiers in storage.
    hashed = hashlib.sha256(payload.device_id.encode()).hexdigest()
    # Simulate storing (MVP: just echo)
    return {"status": "ok", "device_hash": hashed, "received_at": time.time()}

@app.get("/api/v1/health")
def health():
    return {"status": "ok", "time": time.time()}
