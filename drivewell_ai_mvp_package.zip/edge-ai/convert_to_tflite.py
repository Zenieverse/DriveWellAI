# Example stub: convert a Keras model to TFLite with quantization (pseudo-script)
# Replace with your real model path and ensure TensorFlow is installed in your environment.
import tensorflow as tf
import sys

def convert(keras_model_path, tflite_output_path):
    model = tf.keras.models.load_model(keras_model_path)
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    tflite_model = converter.convert()
    with open(tflite_output_path, 'wb') as f:
        f.write(tflite_model)
    print('Converted to', tflite_output_path)

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print('Usage: python convert_to_tflite.py <keras.h5> <out.tflite>')
    else:
        convert(sys.argv[1], sys.argv[2])
