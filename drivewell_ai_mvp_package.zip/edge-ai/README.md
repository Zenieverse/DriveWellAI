# Edge AI helpers

Contains example scripts to convert models to TensorFlow Lite and a basic inference demo structure.

Note: This folder contains *helper scripts*. For training scripts, use your local GPU environment and export a Keras or Torch model first.
