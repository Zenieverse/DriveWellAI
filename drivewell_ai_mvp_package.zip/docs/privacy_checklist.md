# Privacy & Ethics Checklist (DriveWell AI)

- [ ] Explicit consent screen before any camera or biometric access.
- [ ] Default: on-device processing only. Cloud uploads disabled unless opted in.
- [ ] Data minimization: only send anonymized wellness scores, never raw video by default.
- [ ] Provide endpoints for data access, export, and deletion (DPDP/GDPR style).
- [ ] Secure local storage: AES-256 encryption for cached sensitive artifacts.
- [ ] Audit logging for any data exports or model updates.
- [ ] Regular privacy impact assessments during pilot and production phases.
- [ ] Transparent user-facing privacy policy explaining what is collected, why, and retention periods.
