# Pilot Test Plan — DriveWell AI (90-day pilot)

## Objective
Validate detection accuracy, false alarm rate, driver acceptance, and operational benefits for a small fleet (10-25 vehicles).

## Timeline & Phases
1. **Preparation (0-2 weeks)**: Provision devices, consent forms, training materials.
2. **Baseline Data Collection (2-4 weeks)**: Collect labeled sessions with manual annotations for ground truth.
3. **Model Tuning (4-8 weeks)**: Update models with pilot data and deploy edge-updates.
4. **Field Evaluation (8-12 weeks)**: Measure impact metrics (accidents incidents, fatigue alerts, driver feedback).
5. **Analysis & Report (12 weeks)**: Deliver KPI report and recommendations.

## Metrics
- Detection Precision & Recall
- False Alarm Rate (%)
- Driver compliance with rest suggestions
- Change in unplanned stops and incident reports
- Driver satisfaction (survey)

## Safety & Compliance
- All participants sign consent forms.
- No raw video leaves devices without explicit permission.
