# DriveWell AI — README

DriveWell AI is an edge-first, multi-sensor driver wellness monitoring system that detects fatigue, stress, and distraction in real time and provides non-distracting, personalized interventions. The project is built to be retrofit-friendly (smartphone + dashcam + wearables or OBD-II), privacy-first (on-device processing), and fleet-scalable (anonymized analytics dashboard).

See /docs and individual folders for setup instructions.

## Quick links
- `/backend` — FastAPI skeleton + Dockerfile
- `/mobile-app` — Flutter starter template
- `/edge-ai` — model conversion & inference helpers
- `/docs` — privacy checklist, pilot plan, diagrams

